CSE251B_PA2_Code_Instruction
Zunming Zhang
Yue Qiao
Fangzhou Ai

USAGE: 
1) Ensure that all the dataset are contained in the same directory as the scripts (i.e. PA2_submission)
2) Run the script file 'PA2.py' All the parts should be run in a sequence manner 

All graphs and code requested for each section will be run and displayed by running the script corresponding to the part # and letter. 
The scripts that do not begin with 'part' are helper classes and code. Accuracies are printed to the console output.

A copy of all the scripts are also available in notebook form in the private github repository https://github.com/arition/CSE251B-PA/tree/master/PA2 
In the Gradescope submission, a copy of the notebook has been included in the home directory of the submission. Downloading the PA2.ipynb will contain the pre-run cells along with print statements with accuracies.